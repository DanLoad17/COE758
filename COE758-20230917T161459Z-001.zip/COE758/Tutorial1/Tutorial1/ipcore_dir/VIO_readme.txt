The following files were generated for 'VIO' in directory
/home/student2/dzelenov/COE758/Tutorial1/Tutorial1/ipcore_dir/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * VIO.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * VIO.cdc
   * VIO.ngc
   * VIO.vhd
   * VIO.vho

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * VIO.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * VIO.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * VIO.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * VIO_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * VIO.gise
   * VIO.xise
   * _xmsgs/pn_parser.xmsgs

Deliver Readme:
   Readme file for the IP.

   * VIO_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * VIO_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

