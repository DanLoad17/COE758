The following files were generated for 'ila' in directory
/home/student2/dzelenov/COE758/Tutorial1/Tutorial1/ipcore_dir/

XCO file generator:
   Generate an XCO file for compatibility with legacy flows.

   * ila.xco

Creates an implementation netlist:
   Creates an implementation netlist for the IP.

   * ila.cdc
   * ila.ngc
   * ila.vhd
   * ila.vho

Creates an HDL instantiation template:
   Creates an HDL instantiation template for the IP.

   * ila.vho

IP Symbol Generator:
   Generate an IP symbol based on the current project options'.

   * ila.asy

SYM file generator:
   Generate a SYM file for compatibility with legacy flows

   * ila.sym

Generate ISE metadata:
   Create a metadata file for use when including this core in ISE designs

   * ila_xmdf.tcl

Generate ISE subproject:
   Create an ISE subproject for use when including this core in ISE designs

   * _xmsgs/pn_parser.xmsgs
   * ila.gise
   * ila.xise

Deliver Readme:
   Readme file for the IP.

   * ila_readme.txt

Generate FLIST file:
   Text file listing all of the output files produced when a customized core was
   generated in the CORE Generator.

   * ila_flist.txt

Please see the Xilinx CORE Generator online help for further details on
generated files and how to use them.

